package com.os.kotlin_harita

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.*
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.SignInButton
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.android.play.core.integrity.e
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class OtoparkActivity : Activity() {

    private lateinit var mapImageView: ImageView
    private lateinit var usernameEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button
    private lateinit var mapButton: Button
    private lateinit var uyelikButton: Button
    private lateinit var reservasyonButton: Button
    private lateinit var googleSignInButton: SignInButton
    private val RC_SIGN_IN = 9001

    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.otopark)

        // XML dosyasındaki bileşenleri tanımla
      

        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        // GoogleSignInOptions ayarları
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id)) // google-services.json dosyasından alınan web_client_id
            .requestEmail()
            .build()

        val googleSignInClient = GoogleSignIn.getClient(this, gso)



        // Haritaya Tıklayınca
        mapImageView.setOnClickListener {
            val intent = Intent(this@OtoparkActivity, MapsActivity::class.java)
            startActivity(intent)
        }
        // Haritaya Geç Düğmesi
        mapButton.setOnClickListener {
            val intent = Intent(this@OtoparkActivity, MapsActivity::class.java)
            startActivity(intent)
        }

        // Üyelik Düğmesi
        uyelikButton.setOnClickListener {
            val intent = Intent(this@OtoparkActivity, UyelikActivity::class.java)
            startActivity(intent)
        }

        // Giriş yap düğmesine tıklanınca yapılacak işlemi tanımla
        loginButton.setOnClickListener {
            // Kullanıcı adı ve parolayı al
            val username = usernameEditText.text.toString()
            val password = passwordEditText.text.toString()

            // Kullanıcı adı ve parolayı kontrol et (örneğin, boş olup olmadığını kontrol et)
          
        }
        // Google SignIn Düğmesi
        googleSignInButton.setOnClickListener {
            val signInIntent = googleSignInClient.signInIntent
            startActivityForResult(signInIntent, RC_SIGN_IN)
        }

        // Rezervasyon düğmesi
        reservasyonButton.setOnClickListener {
            // RezervasyonActivity'e geçiş
            val intent = Intent(this@OtoparkActivity, ReservasyonActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Google hesabıyla giriş yapma sonucunu kontrol et
        if (requestCode == RC_SIGN_IN) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            handleSignInResult(task)
        }
    }



    private fun handleSignInResult(completedTask: Task<GoogleSignInAccount>) {
        try {
           

        } catch (e: ApiException) {
           
        }
    }

}
