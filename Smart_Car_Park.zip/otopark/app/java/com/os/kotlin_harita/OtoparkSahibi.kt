package com.os.kotlin_harita

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class OtoparkSahibi : AppCompatActivity() {

    private lateinit var username: String
    private lateinit var otoparkAdiEditText: EditText
    private lateinit var otoparkKapasitesiEditText: EditText
    private lateinit var otoparkEnlemEditText: EditText
    private lateinit var otoparkBoylamEditText: EditText
    private lateinit var saatlikUcretEditText: EditText
    private lateinit var guncelleButton: Button
    private lateinit var otoparkKontrolButton: Button
    private lateinit var cikisButton: Button
    private lateinit var baslikTextView: TextView

    val auth = FirebaseAuth.getInstance()

    @SuppressLint("MissingInflatedId", "SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.otoparksahibi)

        // E-posta adresini al
        username = intent.getStringExtra("username") ?: ""

        // XML dosyasındaki bileşenleri tanımla
        otoparkAdiEditText = findViewById(R.id.editTextOtoparkAdi)
        otoparkKapasitesiEditText = findViewById(R.id.editTextOtoparkKapasitesi)
        otoparkEnlemEditText = findViewById(R.id.editTextOtoparkEnlem)
        otoparkBoylamEditText = findViewById(R.id.editTextOtoparkBoylam)
        saatlikUcretEditText = findViewById(R.id.editTextSaatlikUcret)
        guncelleButton = findViewById(R.id.buttonGuncelle)
        otoparkKontrolButton = findViewById(R.id.buttonOtoparkKontrol)
        cikisButton = findViewById(R.id.buttonCikis)
        baslikTextView = findViewById(R.id.textViewBaslik)

        val currentUser = FirebaseAuth.getInstance().currentUser

        // Başlıkta e-posta adresini göster
        baslikTextView.text = "Merhaba $username"

        // Firestore veritabanından bilgileri al ve edittext'lere doldur
        val db = FirebaseFirestore.getInstance()
        val userCollection = db.collection("users").document(username)

        userCollection.get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val otoparkAdi = document.getString("otoparkAdi") ?: ""
                    val kapasite = document.getString("kapasite") ?: ""
                    val enlem = document.getString("enlem") ?: ""
                    val boylam = document.getString("boylam") ?: ""
                    val ucret = document.getString("ucret") ?: ""

                    otoparkAdiEditText.setText(otoparkAdi)
                    otoparkKapasitesiEditText.setText(kapasite)
                    otoparkEnlemEditText.setText(enlem)
                    otoparkBoylamEditText.setText(boylam)
                    saatlikUcretEditText.setText(ucret)
                } else {
                    Toast.makeText(this, "Kullanıcı verisi bulunamadı.", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Veri alınamadı. Hata: ${e.message}", Toast.LENGTH_SHORT).show()
            }

        guncelleButton.setOnClickListener {
            // ... Diğer güncelleme işlemleri ...
           
                )
            )
                .addOnSuccessListener {
                    Toast.makeText(
                        this@OtoparkSahibi,
                        "Otopark bilgileri başarıyla güncellendi.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(
                        this@OtoparkSahibi,
                        "Otopark bilgileri güncellenemedi. Hata: ${e.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
        }

        otoparkKontrolButton.setOnClickListener {
            // Düğmeye tıklandığında otopark_kontrol.xml dosyasını açmak için Intent kullan
            val intent = Intent(this@OtoparkSahibi, OtoparkKontrol::class.java)
            intent.putExtra("username", username)
            startActivity(intent)
        }

        cikisButton.setOnClickListener {
            // Firebase'e e-posta ve şifre ile giriş yapmış kullanıcı varsa çıkış yap
            if (auth.currentUser != null) {
                auth.signOut()
                Toast.makeText(this, "Çıkış yapıldı", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, OtoparkActivity::class.java)
                startActivity(intent)
                // Çıkış yapıldıktan sonra isteğe bağlı diğer işlemleri burada yapabilirsin.
            }

            // Firebase'e Google ile giriş yapmış kullanıcı varsa çıkış yap
            val googleSignInAccount = GoogleSignIn.getLastSignedInAccount(this)
            if (googleSignInAccount != null) {
                val googleSignInClient = GoogleSignIn.getClient(this, GoogleSignInOptions.DEFAULT_SIGN_IN)
                googleSignInClient.signOut()
                    .addOnCompleteListener(this) {
                        Toast.makeText(this, "Google ile çıkış yapıldı", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this, OtoparkActivity::class.java)
                        startActivity(intent)
                        // Çıkış yapıldıktan sonra isteğe bağlı diğer işlemleri burada yapabilirsin.
                    }
            }
        }
    }
}
