package com.os.kotlin_harita

import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.firebase.firestore.FirebaseFirestore
import com.os.kotlin_harita.databinding.ActivityMapsBinding

import java.util.*

@Suppress("DEPRECATION")
class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var konumyonetici: LocationManager
    private lateinit var konumdinleyici: LocationListener
    private lateinit var binding: ActivityMapsBinding

    private var selectedMarker: Marker? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        konumyonetici = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        konumdinleyici = object : LocationListener {
            override fun onLocationChanged(p0: Location) {
                mMap.clear()
                val guncelkonum = LatLng(p0.latitude, p0.longitude)
                mMap.addMarker(
                    MarkerOptions()
                        .position(guncelkonum)
                        .title("Buradasınız")
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
                )
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(guncelkonum, 15f))

                val db = FirebaseFirestore.getInstance()
                db.collection("users")
                    .get()
                    .addOnSuccessListener { result ->
                        for (document in result) {
                            val email = document.id
                            val boylam = document.getString("boylam")?.toDouble()
                            val enlem = document.getString("enlem")?.toDouble()
                            val otoparkAdi = document.getString("otoparkAdi")
                            val ucret = document.getString("ucret").toString()
                            val kapasite = document.getString("kapasite").toString()

                            if (boylam != null && enlem != null && otoparkAdi != null && ucret != null && kapasite != null) {
                                val location = LatLng(enlem, boylam)
                                val marker = mMap.addMarker(
                                    MarkerOptions()
                                        .position(location)
                                        .title(otoparkAdi)
                                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_CYAN))
                                        .snippet("Boş Yer:$kapasite - Ücret: $ucret")
                                )
                            }
                        }
                    }
                    .addOnFailureListener { exception ->
                        exception.printStackTrace()
                    }
            }
        }

        if (ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                1
            )
        } else {
            val networkProviderEnabled = konumyonetici.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

            if (networkProviderEnabled) {
                konumyonetici.requestLocationUpdates(
                    LocationManager.NETWORK_PROVIDER,
                    1,
                    1f,
                    konumdinleyici
                )
            } else {
                Toast.makeText(this, "Konum sağlayıcılarınız kapalı", Toast.LENGTH_SHORT).show()
            }

            val sonkonum = konumyonetici.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            if (sonkonum != null) {
                val sonkonumLATLANG = LatLng(sonkonum.latitude, sonkonum.longitude)
                mMap.addMarker(MarkerOptions().position(sonkonumLATLANG).title("Son Bilinen Konumunuz"))
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(sonkonumLATLANG, 15f))
            }
        }

        mMap.setOnMapClickListener { p0 ->
            mMap.clear()
            val geocoder = Geocoder(this@MapsActivity, Locale.getDefault())
            if (p0 != null) {
                var adres = ""
                try {
                    val adreslistesi = geocoder.getFromLocation(p0.latitude, p0.longitude, 1)
                    if (adreslistesi != null) {
                        if (adreslistesi.isNotEmpty()) {
                            if (adreslistesi[0].thoroughfare != null) {
                                adres += adreslistesi[0].thoroughfare

                                if (adreslistesi[0].subThoroughfare != null) {
                                    adres += adreslistesi[0].subThoroughfare
                                }
                            }
                        }
                    }
                } catch (e: java.lang.Exception) {
                    e.printStackTrace()
                }
                mMap.addMarker(MarkerOptions().position(p0).title(adres))

                mMap.setOnMarkerClickListener { marker ->
                    // Tıklandığında yapılacak işlemleri buraya ekleyin
                    // Marker'a tıklandığında bilgileri göster ve uzun basıldığında navigasyon başlat
                    selectedMarker = marker
                    true
                }
            }
        }

        mMap.setOnMapLongClickListener { p0 ->
            // Uzun basıldığında yapılacak işlemleri buraya ekleyin
            if (selectedMarker != null) {
                // Navigasyon başlatma işlemini buraya ekleyin
                Toast.makeText(this@MapsActivity, "Navigasyon Başlatıldı", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (requestCode == 1) {
            if (grantResults.isNotEmpty()) {
                if (ContextCompat.checkSelfPermission(
                        this,
                        android.Manifest.permission.ACCESS_FINE_LOCATION
                    ) == PackageManager.PERMISSION_GRANTED
                )
                    konumyonetici.requestLocationUpdates(
                        LocationManager.GPS_PROVIDER,
                        1,
                        1f,
                        konumdinleyici
                    )
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }
}
