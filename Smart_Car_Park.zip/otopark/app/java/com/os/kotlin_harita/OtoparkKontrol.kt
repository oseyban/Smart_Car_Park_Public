package com.os.kotlin_harita

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException


@Suppress("NAME_SHADOWING", "DEPRECATION")
class OtoparkKontrol : AppCompatActivity() {

    private lateinit var username: String
    private lateinit var welcomeText: TextView
    private lateinit var otoparkNameText: TextView
    private lateinit var capacityText: TextView
    private lateinit var reservationListView: ListView

    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore
    private lateinit var reservations: MutableList<View>
    private lateinit var reservationAdapter: ReservationAdapter
    private lateinit var otoparkAdi: String

    @SuppressLint("SetTextI18n", "CutPasteId", "InflateParams")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.otopark_kontrol)

        username = intent.getStringExtra("username") ?: ""

        welcomeText = findViewById(R.id.welcomeText)
        otoparkNameText = findViewById(R.id.otoparkNameText)
        capacityText = findViewById(R.id.capacityText)
        reservationListView = findViewById(R.id.reservationListView)

        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        reservationAdapter = ReservationAdapter(this, mutableListOf())
        reservationListView.adapter = reservationAdapter

       //Firebase işlemleri...
                        }
                }
            }
    }

    private fun deleteReservation(adSoyad: String, rezervasyonTarihi: String) {
        //Silme işlemleri
                        }
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Rezervasyon bilgileri alınamadı. Hata: ${it.message}", Toast.LENGTH_SHORT)
                    .show()
            }
    }



    @SuppressLint("CutPasteId", "InflateParams")
    private fun refreshListView() {
        // Firebase'den verileri çek ve listeyi güncelle
        firestore.collection("reservasyon")
            .whereEqualTo("otoparkAdi", otoparkAdi)
            .get()
            .addOnSuccessListener { result ->
                val updatedReservations = mutableListOf<View>()

                //güncelleme işlemleri

                    // Onayla düğmesine tıklanınca
                    // Onayla düğmesine tıklanınca

                    onaylaButton.setOnClickListener {
                     //Onaylama işlemleri
                        }
                    }

                    // Sil düğmesine tıklanınca
                    silButton.setOnClickListener {
                        // İlgili rezervasyon bilgilerini al
                        val reservationInfo = (cardView.findViewById<TextView>(R.id.cardTextView))?.text.toString()
                        val adSoyad = extractAdSoyad(reservationInfo)
                        val rezervasyonTarihi = extractRezervasyonTarihi(reservationInfo)

                        // Ad Soyad ve Rezervasyon Tarihi bilgileri null değilse listener'ı çağır
                        if (adSoyad != null && rezervasyonTarihi != null) {
                            deleteReservation(adSoyad, rezervasyonTarihi)
                        } else {
                            // Bilgileri çıkarırken hata oluştu
                            Toast.makeText(
                                this,
                                "Bilgileri çıkarırken hata oluştu.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }

                // Güncellenmiş verileri kullanarak listeyi güncelle
                reservationAdapter.updateData(updatedReservations)
            }
            .addOnFailureListener { e ->
                Toast.makeText(
                    this,
                    "Rezervasyonlar alınamadı. Hata: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
    }

    private fun getDeviceIdFromReservation(adSoyad: String, rezervasyonTarihi: String) {
        firestore.collection("reservasyon")
            .whereEqualTo("adSoyad", adSoyad)
            .whereEqualTo("rezervasyonTarihi", rezervasyonTarihi)
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    // İlgili rezervasyonun deviceID'sini al
                    val deviceId = document.getString("deviceID")
                    if (deviceId != null) {
                        // DeviceID'yi kullanarak işlemleri gerçekleştirin
                        val messageTitle="Otopark Rezervasyon"
                        val messageBody="Otopark Rezervasyonunuz Onaylandı"
                        sendFCMMessageToDevice(deviceId, messageTitle, messageBody)
                    } else {
                        // DeviceID bulunamadı, bir hata durumunu ele alabilirsiniz
                        Toast.makeText(
                            this,
                            "DeviceID bulunamadı.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
            .addOnFailureListener {
                // Firestore sorgusunda hata oluştu
                Toast.makeText(
                    this,
                    "Rezervasyon bilgileri alınamadı. Hata: ${it.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
    }

    private fun sendFCMMessageToDevice(deviceId: String, messageTitle: String, messageBody: String) {
        // FCM token'ını almak için SharedPreferences'ten çekme (saklama kodu önceki örnekten alınmıştır)
        val sharedPreferences = getSharedPreferences("MySharedPreferences", Context.MODE_PRIVATE)
        val deviceToken = sharedPreferences.getString("FCM_TOKEN", "")
        Log.d("OtoparkKontrol", "FCM mesajı gönderiliyor. Device ID: $deviceId, Başlık: $messageTitle, İçerik: $messageBody")


        // FCM mesajını oluşturma
        // FCM mesajını oluşturma
        val jsonBody = JSONObject()
        jsonBody.put("to", deviceId)
        jsonBody.put("priority", "high")

// Bildirim başlığı ve içeriğini "notification" alanına ekle
        val notification = JSONObject()
        notification.put("title", messageTitle)
        notification.put("body", messageBody)

        jsonBody.put("notification", notification)


        val requestBody = jsonBody.toString().toRequestBody("application/json".toMediaTypeOrNull())

        // FCM mesajını gönderme
        val serverKey = "AAAAZ8nC-P4:APA91bHoPIusUkbyNZzzR-HoMWUCaDmfIbQ91u29f7QR_ZNzmRq1tVlSsbT8XlYV-bu0hfAIZXemezDxJyiS89EUYq0tV6rst3Y6ejUHxVG2jNu_Nzr4pZf1L8HqdEcqoWQLmL0CHqsq"
        val request = Request.Builder()
            .url("https://fcm.googleapis.com/fcm/send")
            .post(requestBody)
            .addHeader("Content-Type", "application/json")
            .addHeader("Authorization", "key=$serverKey")
            .build()

        val client = OkHttpClient()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("OtoparkKontrol", "FCM mesajı gönderme hatası: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                Log.d("OtoparkKontrol", "FCM mesajı başarıyla gönderildi.")
            }
        })
    }





    private fun extractAdSoyad(reservationInfo: String): String? {
        val adSoyadKeyword = "Ad Soyad:"
        val startIndex = reservationInfo.indexOf(adSoyadKeyword)

        if (startIndex != -1) {
            val adSoyadStartIndex = startIndex + adSoyadKeyword.length
            val adSoyadEndIndex = reservationInfo.indexOf("\n", adSoyadStartIndex)

            if (adSoyadEndIndex != -1) {
                return reservationInfo.substring(adSoyadStartIndex, adSoyadEndIndex).trim()
            }
        }
        return null
    }

    private fun extractRezervasyonTarihi(reservationInfo: String): String? {
        val rezervasyonTarihiKeyword = "Rezervasyon Tarihi:"
        val startIndex = reservationInfo.indexOf(rezervasyonTarihiKeyword)

        if (startIndex != -1) {
            val tarihiStartIndex = startIndex + rezervasyonTarihiKeyword.length
            val tarihiEndIndex = reservationInfo.indexOf("\n", tarihiStartIndex)

            if (tarihiEndIndex != -1) {
                return reservationInfo.substring(tarihiStartIndex, tarihiEndIndex).trim()
            }
        }
        return null
    }
}

class ReservationAdapter(private val context: Context, private val reservations: MutableList<View>) : BaseAdapter() {

    var onDeleteClickListener: ((adSoyad: String, rezervasyonTarihi: String) -> Unit)? = null

    override fun getCount(): Int {
        return reservations.size
    }

    override fun getItem(position: Int): Any {
        return reservations[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        return reservations[position]
    }

    fun updateData(updatedData: List<View>) {
        reservations.clear()
        reservations.addAll(updatedData)
        notifyDataSetChanged()
    }


}

