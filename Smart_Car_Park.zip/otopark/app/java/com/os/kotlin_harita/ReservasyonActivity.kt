package com.os.kotlin_harita

import android.app.DatePickerDialog
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.messaging.FirebaseMessaging
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class ReservasyonActivity : AppCompatActivity() {

    private lateinit var spinner: Spinner
    private lateinit var editTextAdSoyad: EditText
    private lateinit var editTextSuresi: EditText
    private lateinit var spinnerBaslangicSaat: Spinner
    private lateinit var buttonReservasyonYap: Button
    private lateinit var buttonUcretOde: Button
    private lateinit var textViewReservasyonTarihi: TextView

    private var selectedDate = Calendar.getInstance()
    var deviceID = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reservasyon)

        initializeViews()
        setupFirestore()
        setupListeners()
    }

    private fun initializeViews() {
        spinner = findViewById(R.id.spinner)
        editTextAdSoyad = findViewById(R.id.editTextAdSoyad)
        editTextSuresi = findViewById(R.id.editTextSuresi)
        spinnerBaslangicSaat = findViewById(R.id.spinnerBaslangicSaat)
        buttonReservasyonYap = findViewById(R.id.buttonReservasyonYap)
        buttonUcretOde = findViewById(R.id.buttonUcretOde)
        textViewReservasyonTarihi = findViewById(R.id.textViewReservasyonTarihi)
    }

    private fun setupFirestore() {
        val db = FirebaseFirestore.getInstance()

        db.collection("users")
            .get()
            .addOnSuccessListener { result ->
                val otoparkList = ArrayList<String>()
                otoparkList.add("Otopark Seçiniz")

                for (document in result) {
                    val otoparkAdi = document.getString("otoparkAdi")
                    if (otoparkAdi != null) {
                        otoparkList.add(otoparkAdi)
                    }
                }

                setupSpinner(spinner, otoparkList)

                val saatler = resources.getStringArray(R.array.saatler)
                setupSpinner(spinnerBaslangicSaat, saatler.toList())
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Veri getirme hatası: $exception", Toast.LENGTH_SHORT).show()
            }
    }

    private fun setupListeners() {
        val buttonTarihSec: Button = findViewById(R.id.buttonTarihSec)
        buttonTarihSec.setOnClickListener {
            showDatePickerDialog()
        }

        buttonReservasyonYap.setOnClickListener {
            reservasyonuYap()
        }

        buttonUcretOde.setOnClickListener {
            // TODO: Ücret ödeme işlemleri
        }
    }

    private fun setupSpinner(spinner: Spinner, itemList: List<String>) {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, itemList)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
    }

    private fun reservasyonuYap() {
       //rezervasyon işlemleri
        }

        FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
            if (task.isSuccessful) {
                val token = task.result
                deviceID = token

                // Token'ı SharedPreferences'e kaydet
                val sharedPreferences = getSharedPreferences("MySharedPreferences", Context.MODE_PRIVATE)
                sharedPreferences.edit().putString("FCM_TOKEN", token).apply()

                // Firestore'a kaydet
                kaydetFirestore(token, adSoyad, suresi, baslangicSaat, otoparkAdi, rezervasyonTarihiStr, currentTime)
            } else {
                Log.e("OtoparkKontrol", "Fetching FCM registration token failed", task.exception)
            }
        })
    }

    private fun kaydetFirestore(
        token: String,
        adSoyad: String,
        suresi: Int,
        baslangicSaat: String,
        otoparkAdi: String,
        rezervasyonTarihiStr: String,
        currentTime: Long
    ) {
        val db = FirebaseFirestore.getInstance()

       //firebase e kaydetme işlemleri
    }

    private fun showDatePickerDialog() {
        val textViewReservasyonTarihi: TextView = findViewById(R.id.textViewReservasyonTarihi) ?: return

        val datePicker = DatePickerDialog(
            this,
            DatePickerDialog.OnDateSetListener { _, year, month, dayOfMonth ->
                selectedDate.set(Calendar.YEAR, year)
                selectedDate.set(Calendar.MONTH, month)
                selectedDate.set(Calendar.DAY_OF_MONTH, dayOfMonth)

                val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                textViewReservasyonTarihi.text = sdf.format(selectedDate.time)
            },
            selectedDate.get(Calendar.YEAR),
            selectedDate.get(Calendar.MONTH),
            selectedDate.get(Calendar.DAY_OF_MONTH)
        )
        datePicker.datePicker.minDate = System.currentTimeMillis() - 1000
        datePicker.show()
    }
}
